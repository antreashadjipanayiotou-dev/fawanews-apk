package com.fawanews.mobile

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var pageReady = false

    // Click the site's own schedule-refresh control, not the whole page.
    private val scheduleRefresh = object : Runnable {
        override fun run() {
            if (pageReady && ::webView.isInitialized) {
                val js = """
                    (function() {
                      const wanted = 'press to refresh the schedule';
                      const candidates = Array.from(document.querySelectorAll(
                        'button, a, [role="button"], input[type="button"], input[type="submit"], div, span'
                      ));
                      const el = candidates.find(e => {
                        const text = ((e.innerText || e.value || e.getAttribute('aria-label') || '') + '')
                          .replace(/\s+/g, ' ').trim().toLowerCase();
                        if (!text || text.length > 100 || !text.includes(wanted)) return false;
                        const r = e.getBoundingClientRect();
                        const s = window.getComputedStyle(e);
                        return r.width > 0 && r.height > 0 &&
                               s.visibility !== 'hidden' && s.display !== 'none';
                      });
                      if (el) { el.click(); return 'clicked'; }
                      return 'not-found';
                    })();
                """.trimIndent()
                webView.evaluateJavascript(js, null)
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        val content = FrameLayout(this)
        content.addView(webView, FrameLayout.LayoutParams(-1, -1))
        content.addView(progress, FrameLayout.LayoutParams(-1, 5))
        root.addView(content)
        setContentView(root)

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = false
            displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                pageReady = false
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
            }
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: android.webkit.WebResourceRequest?
            ): Boolean = false
        }

        if (savedInstanceState == null) webView.loadUrl("https://fawanews.sc/")
        else webView.restoreState(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(scheduleRefresh)
        handler.postDelayed(scheduleRefresh, 60_000L)
    }

    override fun onPause() {
        handler.removeCallbacks(scheduleRefresh)
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(scheduleRefresh)
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
